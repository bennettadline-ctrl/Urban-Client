import json
import os
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

try:
    import requests
    import minecraft_launcher_lib
except ImportError:
    requests = None
    minecraft_launcher_lib = None

APP = "Urban"
MC_VERSION = "26.2"
MODS = [
    "sodium",
    "lithium",
    "ferrite-core",
    "immediatelyfast",
    "entityculling",
    "fabric-api",
    "dynamic-fps",
]

NAVY = "#071426"
NAVY2 = "#0B1F38"
BLUE = "#3EA6FF"
LIGHT = "#8FD3FF"
WHITE = "#F4F8FC"
MUTED = "#8EA4B8"
GREEN = "#54E38E"
RED = "#FF6B7A"

BASE = Path(os.environ.get("APPDATA", Path.home())) / "UrbanLauncher"
MC_DIR = Path(os.environ.get("APPDATA", Path.home())) / ".minecraft"
CONFIG = BASE / "config.json"
BASE.mkdir(parents=True, exist_ok=True)

DEFAULT = {"version": MC_VERSION, "ram": "4G", "client_id": "", "redirect_url": ""}

def load_config():
    if CONFIG.exists():
        try:
            d = json.loads(CONFIG.read_text())
            return {**DEFAULT, **d}
        except Exception:
            pass
    return DEFAULT.copy()

cfg = load_config()

def save_config():
    CONFIG.write_text(json.dumps(cfg, indent=2))

def log(msg):
    root.after(0, lambda: status.set(msg))

def modrinth_install(version):
    mods_dir = MC_DIR / "mods"
    mods_dir.mkdir(parents=True, exist_ok=True)
    headers = {"User-Agent": "UrbanLauncher/1.0 (personal Minecraft launcher)"}
    installed = []
    for slug in MODS:
        log(f"Finding {slug}...")
        url = f"https://api.modrinth.com/v2/project/{slug}/version"
        params = {"loaders": json.dumps(["fabric"]),
                  "game_versions": json.dumps([version]),
                  "featured": "true"}
        r = requests.get(url, params=params, headers=headers, timeout=30)
        r.raise_for_status()
        versions = r.json()
        if not versions:
            # Try any listed version for this MC version, not just featured.
            params.pop("featured", None)
            r = requests.get(url, params=params, headers=headers, timeout=30)
            r.raise_for_status()
            versions = r.json()
        if not versions:
            raise RuntimeError(f"No Fabric build of {slug} was found for Minecraft {version}.")
        chosen = next((v for v in versions if v.get("version_type") == "release"), versions[0])
        files = chosen.get("files", [])
        jar = next((f for f in files if f.get("filename", "").endswith(".jar")), None)
        if not jar:
            raise RuntimeError(f"No .jar file found for {slug}.")
        out = mods_dir / jar["filename"]
        if not out.exists():
            log(f"Downloading {slug}...")
            rr = requests.get(jar["url"], headers=headers, timeout=60)
            rr.raise_for_status()
            out.write_bytes(rr.content)
        installed.append(slug)
    return installed

def install_game(version):
    if minecraft_launcher_lib is None:
        raise RuntimeError("Dependencies are not installed. Run setup.bat first.")
    callback = {"setStatus": lambda s: log(str(s))}
    log("Installing Minecraft...")
    minecraft_launcher_lib.install.install_minecraft_version(
        version, str(MC_DIR), callback=callback
    )
    log("Installing Fabric...")
    # Current launcher-lib exposes this module on supported releases.
    if hasattr(minecraft_launcher_lib, "mod_loader"):
        loader = minecraft_launcher_lib.mod_loader.get_mod_loader("fabric")
        loader.install(version, str(MC_DIR), callback=callback)
    else:
        minecraft_launcher_lib.fabric.install_fabric(
            version, str(MC_DIR), callback=callback
        )
    log("Installing Urban FPS mods...")
    modrinth_install(version)
    log("Urban is ready.")

def login_and_launch(version, ram):
    # Microsoft login requires a registered Azure application.
    # Urban opens the Microsoft authorization URL and asks the user to paste
    # the final redirected URL back into the launcher.
    client_id = cfg.get("client_id", "").strip()
    redirect_url = cfg.get("redirect_url", "").strip()
    if not client_id or not redirect_url:
        raise RuntimeError(
            "Open Settings and enter your Microsoft/Azure Client ID and Redirect URL. "
            "Urban uses Microsoft's normal sign-in flow; it never asks for your password."
        )

    login_url, state, verifier = minecraft_launcher_lib.microsoft_account.get_secure_login_data(
        client_id, redirect_url
    )
    webbrowser.open(login_url)
    code_url = ask_url("Microsoft Login", 
        "Sign in in your browser.\n\nAfter Microsoft redirects you, copy the FULL URL from the address bar and paste it here:")
    auth_code = minecraft_launcher_lib.microsoft_account.parse_auth_code_url(code_url, state)
    data = minecraft_launcher_lib.microsoft_account.complete_login(
        client_id, None, redirect_url, auth_code, verifier
    )

    # Install the game/modpack before launch.
    install_game(version)

    options = {
        "username": data["name"],
        "uuid": data["id"],
        "token": data["access_token"],
        "jvmArguments": [f"-Xmx{ram}", f"-Xms{ram}"]
    }
    command = minecraft_launcher_lib.command.get_minecraft_command(
        version, str(MC_DIR), options
    )
    log("Launching Minecraft...")
    subprocess.Popen(command, cwd=str(MC_DIR))
    log(f"Urban launched as {data['name']}.")

def ask_url(title, prompt):
    result = {"value": None}
    win = tk.Toplevel(root)
    win.title(title)
    win.configure(bg=NAVY)
    win.geometry("720x230")
    win.transient(root)
    win.grab_set()

    tk.Label(win, text=prompt, bg=NAVY, fg=WHITE, wraplength=650,
             justify="left", font=("Segoe UI", 11)).pack(padx=25, pady=(25, 12))
    entry = tk.Entry(win, bg=NAVY2, fg=WHITE, insertbackground=WHITE,
                     relief="flat", font=("Segoe UI", 10))
    entry.pack(fill="x", padx=25, ipady=9)
    entry.focus_set()

    def done():
        result["value"] = entry.get().strip()
        win.destroy()

    tk.Button(win, text="CONTINUE", command=done, bg=BLUE, fg="white",
              activebackground=LIGHT, relief="flat", font=("Segoe UI", 10, "bold"),
              padx=18, pady=8).pack(pady=18)
    root.wait_window(win)
    if not result["value"]:
        raise RuntimeError("Login cancelled.")
    return result["value"]

def start_install():
    version = version_var.get().strip()
    ram = ram_var.get().strip()
    cfg["version"] = version
    cfg["ram"] = ram
    save_config()

    def work():
        try:
            install_game(version)
            root.after(0, lambda: messagebox.showinfo("Urban", "Urban FPS setup is installed."))
        except Exception as e:
            log("Setup failed.")
            root.after(0, lambda: messagebox.showerror("Urban setup error", str(e)))
    threading.Thread(target=work, daemon=True).start()

def start_launch():
    version = version_var.get().strip()
    ram = ram_var.get().strip()
    cfg["version"] = version
    cfg["ram"] = ram
    save_config()

    def work():
        try:
            login_and_launch(version, ram)
        except Exception as e:
            log("Launch failed.")
            root.after(0, lambda: messagebox.showerror("Urban launch error", str(e)))
    threading.Thread(target=work, daemon=True).start()

def settings():
    win = tk.Toplevel(root)
    win.title("Urban Settings")
    win.configure(bg=NAVY)
    win.geometry("650x330")
    win.transient(root)

    tk.Label(win, text="Microsoft Client ID", bg=NAVY, fg=WHITE,
             font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=30, pady=(25, 6))
    cid = tk.Entry(win, bg=NAVY2, fg=WHITE, insertbackground=WHITE, relief="flat")
    cid.pack(fill="x", padx=30, ipady=9)
    cid.insert(0, cfg.get("client_id", ""))

    tk.Label(win, text="Redirect URL", bg=NAVY, fg=WHITE,
             font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=30, pady=(18, 6))
    red = tk.Entry(win, bg=NAVY2, fg=WHITE, insertbackground=WHITE, relief="flat")
    red.pack(fill="x", padx=30, ipady=9)
    red.insert(0, cfg.get("redirect_url", ""))

    tk.Label(win, text="Urban uses Microsoft's browser login. Never enter your Microsoft password into Urban.",
             bg=NAVY, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", padx=30, pady=15)

    def save():
        cfg["client_id"] = cid.get().strip()
        cfg["redirect_url"] = red.get().strip()
        save_config()
        win.destroy()
        log("Settings saved.")

    tk.Button(win, text="SAVE", command=save, bg=BLUE, fg="white",
              relief="flat", font=("Segoe UI", 10, "bold"), padx=24, pady=8).pack()

root = tk.Tk()
root.title("Urban Launcher")
root.geometry("900x600")
root.minsize(820, 540)
root.configure(bg=NAVY)

version_var = tk.StringVar(value=cfg["version"])
ram_var = tk.StringVar(value=cfg["ram"])
status = tk.StringVar(value="Urban ready.")

# Header
header = tk.Frame(root, bg=NAVY, height=95)
header.pack(fill="x")
header.pack_propagate(False)

tk.Label(header, text="URBAN", bg=NAVY, fg=WHITE,
         font=("Segoe UI", 30, "bold")).pack(side="left", padx=38, pady=22)
tk.Label(header, text="MINECRAFT PERFORMANCE CLIENT", bg=NAVY, fg=LIGHT,
         font=("Segoe UI", 10, "bold")).pack(side="left", pady=31)

tk.Button(header, text="⚙ SETTINGS", command=settings, bg=NAVY2, fg=LIGHT,
          relief="flat", activebackground=BLUE, activeforeground="white",
          font=("Segoe UI", 9, "bold"), padx=15, pady=8).pack(side="right", padx=30)

body = tk.Frame(root, bg=NAVY2)
body.pack(fill="both", expand=True, padx=24, pady=(0, 24))

tk.Label(body, text="URBAN FPS", bg=NAVY2, fg=WHITE,
         font=("Segoe UI", 24, "bold")).pack(anchor="w", padx=34, pady=(32, 5))
tk.Label(body, text="Fabric + automatically managed performance mods",
         bg=NAVY2, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", padx=34)

panel = tk.Frame(body, bg=NAVY)
panel.pack(fill="x", padx=34, pady=28)

def field(parent, label, var, values):
    f = tk.Frame(parent, bg=NAVY)
    f.pack(side="left", padx=18, pady=20)
    tk.Label(f, text=label, bg=NAVY, fg=MUTED,
             font=("Segoe UI", 9, "bold")).pack(anchor="w")
    box = tk.OptionMenu(f, var, *values)
    box.config(bg=NAVY2, fg=WHITE, activebackground=BLUE,
               activeforeground="white", relief="flat", highlightthickness=0,
               width=16, font=("Segoe UI", 10))
    box["menu"].config(bg=NAVY2, fg=WHITE)
    box.pack(pady=(6, 0))

field(panel, "MINECRAFT", version_var, ["26.2", "26.1", "1.21.11", "1.21.10", "1.21.8"])
field(panel, "RAM", ram_var, ["2G", "4G", "6G", "8G", "10G"])

buttons = tk.Frame(body, bg=NAVY2)
buttons.pack(pady=3)

tk.Button(buttons, text="INSTALL / UPDATE FPS PACK", command=start_install,
          bg=NAVY, fg=LIGHT, activebackground=BLUE, activeforeground="white",
          relief="flat", font=("Segoe UI", 10, "bold"), padx=22, pady=13).pack(side="left", padx=7)

tk.Button(buttons, text="LAUNCH URBAN", command=start_launch,
          bg=BLUE, fg="white", activebackground=LIGHT, activeforeground=NAVY,
          relief="flat", font=("Segoe UI", 11, "bold"), padx=38, pady=13).pack(side="left", padx=7)

mods_text = "SODIUM  •  LITHIUM  •  FERRITECORE  •  IMMEDIATELYFAST  •  ENTITYCULLING  •  DYNAMIC FPS"
tk.Label(body, text=mods_text, bg=NAVY2, fg=MUTED,
         font=("Segoe UI", 8, "bold"), wraplength=730).pack(pady=28)

tk.Label(root, textvariable=status, bg=NAVY, fg=GREEN,
         font=("Segoe UI", 9)).pack(fill="x", ipady=9)

root.mainloop()
