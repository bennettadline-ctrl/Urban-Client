@echo off
title Urban Launcher Setup
cd /d "%~dp0"
echo.
echo ================================
echo        URBAN LAUNCHER
echo ================================
echo.
echo Installing Python dependencies...
py -m pip install --upgrade pip
py -m pip install requests minecraft-launcher-lib
echo.
echo Starting Urban...
py urban_launcher.py
pause
