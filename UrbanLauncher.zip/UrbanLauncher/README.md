# URBAN LAUNCHER

Urban is a navy/light-blue custom Minecraft Java launcher shell.

## What it does

- Custom Urban UI
- Minecraft/Fabric installation
- Automatically downloads compatible Fabric performance mods from Modrinth
- Launches Minecraft through minecraft-launcher-lib
- Microsoft browser login (no password stored by Urban)
- RAM selector
- Minecraft version selector

## First setup on Windows

1. Extract this folder.
2. Double-click `setup.bat`.
3. Urban installs its Python dependencies.
4. Open Settings.
5. Add a Microsoft/Azure Client ID + Redirect URL for the normal Microsoft OAuth flow.
6. Click `INSTALL / UPDATE FPS PACK`.
7. Click `LAUNCH URBAN`.

## Performance mods

Urban automatically looks for Fabric builds of:
- Sodium
- Lithium
- FerriteCore
- ImmediatelyFast
- Entity Culling
- Fabric API
- Dynamic FPS

The launcher checks Modrinth at install time so it doesn't ship stale `.jar` files.

## Important

Minecraft mod compatibility changes by Minecraft version. Urban checks Modrinth for the selected version rather than assuming one old mod file works forever.

Urban does not bypass Minecraft ownership or authentication.
